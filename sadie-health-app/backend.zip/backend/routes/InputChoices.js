// backend/routes/inputChoices.js
const express = require('express');
const router = express.Router();
const dbConnection = require('../dbConnection'); // Import the MySQL connection

router.post('/submit', (req, res) => {
  const { glucoseReading, foodSameAsYesterday, changedField } = req.body;
  const sql = `
    INSERT INTO input_choices (glucose_reading, food_same_as_yesterday, changed_field)
    VALUES (?, ?, ?)
  `;
  const values = [glucoseReading, foodSameAsYesterday, changedField];
  
  dbConnection.query(sql, values, (error, result) => {
    if (error) {
      console.error('Error storing input choice:', error);
      res.status(500).json({ message: 'An error occurred' });
    } else {
      res.status(201).json({ message: 'Input choice stored successfully' });
    }
  });
});

module.exports = router;
