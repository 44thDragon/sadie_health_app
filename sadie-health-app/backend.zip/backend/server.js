const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const inputChoicesRoutes = require('./routes/inputChoices');

const app = express();

const dbConnection = mysql.createConnection({
  host: 'localhost',
  user: 'sadie_user',
  password: 'Juiced909!',
  database: 'sadivcly_sadie_health_data',
});

dbConnection.connect((error) => {
  if (error) {
    console.error('Error connecting to MySQL database:', error);
  } else {
    console.log('Connected to MySQL database');
  }
});

app.use(bodyParser.json());

app.use('/api/input-choices', inputChoicesRoutes);

const PORT = process.env.PORT || 3306;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
