import React, { useState } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [glucoseReading, setGlucoseReading] = useState('');
  const [foodSameAsYesterday, setFoodSameAsYesterday] = useState(null);
  const [changedField, setChangedField] = useState(null);

  const handleGlucoseChange = (event) => {
    setGlucoseReading(event.target.value);
  };

  const handleFoodOptionClick = (value) => {
    setFoodSameAsYesterday(value);
    setChangedField(null); // Reset changedField when option changes
  };

  const handleChangedFieldClick = (field) => {
    setChangedField(field);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      await axios.post('http://localhost:3306/api/input-choices/submit', {
        glucoseReading,
        foodSameAsYesterday,
        changedField,
      });
      alert('Input choice stored successfully');
    } catch (error) {
      alert('An error occurred while storing input choice');
      console.error(error);
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Hello, World!</h1>
        <p>Welcome to my React.js app on sadie.io</p>
        <form onSubmit={handleSubmit}>
          <div className="label-container">
            <label>What was Sadie's glucose reading?</label>
            <input
              type="number"
              value={glucoseReading}
              onChange={handleGlucoseChange}
            />
          </div>
          <div className="question-container">
            <p>Is the food brand and serving size the same as yesterday?</p>
            <div className="options-container">
              <button
                type="button"
                className={`option-button ${
                  foodSameAsYesterday === 'yes' ? 'active' : ''
                }`}
                onClick={() => handleFoodOptionClick('yes')}
              >
                Yes
              </button>
              <button
                type="button"
                className={`option-button ${
                  foodSameAsYesterday === 'no' ? 'active' : ''
                }`}
                onClick={() => handleFoodOptionClick('no')}
              >
                No
              </button>
            </div>
          </div>
          {foodSameAsYesterday === 'no' && (
            <div className="additional-fields">
              <p>What changed?</p>
              <div className="options-container">
                <button
                  type="button"
                  className={`option-button ${changedField === 'food' ? 'active' : ''}`}
                  onClick={() => handleChangedFieldClick('food')}
                >
                  Food
                </button>
                <button
                  type="button"
                  className={`option-button ${changedField === 'servingSize' ? 'active' : ''
                    }`}
                  onClick={() => handleChangedFieldClick('servingSize')}
                >
                  Serving Size
                </button>
              </div>
            </div>
          )}

          <button type="submit">Submit</button>
        </form>
      </header>
    </div>
  );
}

export default App;
